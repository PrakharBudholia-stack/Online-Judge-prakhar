import { defineConfig } from 'vite';
import reactRefresh from '@vitejs/plugin-react-refresh';

export default defineConfig({
  plugins: [reactRefresh()],
  server: {
    port: 5000, // Specify the port for the Vite development server
    proxy: {
      '/api': 'http://localhost:3000' // Proxy API requests to the backend running on port 3000
    }
  }
});