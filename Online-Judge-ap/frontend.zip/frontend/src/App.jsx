import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import { AuthProvider } from './auth/AuthContext.jsx';
import Login from './components/Login.jsx';
import Register from './components/Register.jsx';
import QuestionList from './components/QuestionList.jsx';
import QuestionDetail from './components/QuestionDetail.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="App">
          <Switch>
            <Route path="/login" component={Login} />
            <Route path="/register" component={Register} />
            <ProtectedRoute path="/questions/:id" component={QuestionDetail} />
            <ProtectedRoute exact path="/" component={QuestionList} />
          </Switch>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;