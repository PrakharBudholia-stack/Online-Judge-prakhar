import React, { useEffect, useState } from 'react';
import axios from 'axios';
import CodeEditor from './CodeEditor';

function QuestionDetail({ match }) {
  const [question, setQuestion] = useState(null);

  useEffect(() => {
    const fetchQuestion = async () => {
      try {
        const response = await axios.get(`/api/questions/${match.params.id}`);
        setQuestion(response.data);
      } catch (error) {
        console.error('Error fetching question:', error);
      }
    };

    fetchQuestion();
  }, [match.params.id]);

  if (!question) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <h1>{question.title}</h1>
      <p>{question.description}</p>
      <CodeEditor questionId={question._id} />
    </div>
  );
}

export default QuestionDetail;